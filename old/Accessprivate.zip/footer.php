<?php include"link.php"?>
<div class="container-flued">
<!-- Footer -->
<footer class="page-footer font-small" style="background:#312e2e;color:#fff;padding-top: 05px">


  <!-- Footer Links -->
  <div class="container text-center text-md-left mt-4">

    <!-- Grid row -->
    <div class="row mt-3">

      <!-- Grid column -->
      <div class="col-md-3 col-lg-4 col-xl-3 mx-auto mb-4">

        <!-- Content -->
        <h6 class="text-uppercase font-weight-bold">Eseva</h6>
        <hr class="deep-purple accent-2 mb-2 mt-0 d-inline-block mx-auto" style="width: 60px;">
        <p class="esevah">Access Private Limited (ASC) offers the convenience of online accesses to all citizens effectively ending the digital divide. You can now use our innovative process and extensive infrastructure and obtain these services close to home.</p>

      </div>
      <!-- Grid column -->

      <!-- Grid column -->
      <div class="col-md-2 col-lg-2 col-xl-2 mx-auto mb-4">

        <!-- Links -->
        <h6 class="text-uppercase font-weight-bold">Usefull Links</h6>
        <hr class="deep-purple accent-2 mb-2 mt-0 d-inline-block mx-auto" style="width: 60px;">
        <p>
          <a style="color:#fff"; href="http://evontest.com/ASC/index.php">Home</a>
        </p>
  
        <p style="color:#fff;>
          <a href="#! ">About Us</a>
        </p>
        </div>
      
      <div class="col-md-2 col-lg-2 col-xl-2 mx-auto mb-4">

        <!-- Links -->
        <h6 class="text-uppercase font-weight-bold">Legal</h6>
        <hr class="deep-purple accent-2 mb-2 mt-0 d-inline-block mx-auto" style="width: 60px;">

        <p>
         <a style="color:#fff;" href="http://localhost/ASC/Faq.php">FAQ</a>
        </p>
        <p>
            <a style="color:#fff;" href="http://localhost/ASC/terms%20&%20conditions.php">Terms & Conditions</a>
        </p>
        <p>
          <a style="color:#fff;" href="http://localhost/ASC/Privacy%20Policy.php">Privacy Policy</a>
        </p>
      </div>
      <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mb-md-0 mb-4">

        <!-- Links -->
        <h6 class="text-uppercase font-weight-bold">Contact</h6>
        <hr class="deep-purple accent-2 mb-2 mt-0 d-inline-block mx-auto" style="width: 60px;">
        <p>
          <i class="fas fa-home mr-3"></i>ACSES Corporate Private Limited</p>
        <p>
          <i class="fas fa-envelope mr-3"></i> info@.acses.in</p>
        <p>
          <i class=""></i><b>CIN</b> : U74999KA2021PTC146822</p>
        <p>
          

      </div>
      <!-- Grid column -->

    </div>
    <!-- Grid row -->

  </div>
  <!-- Footer Links -->
 

  <section style="background:#000;padding-top:10px;padding-left: 30px;padding-right: 30px">
<div class="row">
    <div class="s2 col-md-6">
        <p class="text-lowercase font-weight-bold text-left">© 2021 Copyright</p>
    </div>


    <div class="s2 col-md-6">
         <p class="text-lowercase font-weight-bold text-right">Design by Evon IT Solutions</p>
    </div>
</div>

</section>

</footer>
</div>
<!-- Footer -->