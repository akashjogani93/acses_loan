<?php include"link.php"?>
 <?php include "header.php"?>
<style>
    @media screen and (max-width: 600px){
.visionhead1 {
    margin-top: 0;
    margin-bottom: 1rem;
}
}
     @media screen and (max-width:768px) {
.c3{
     width: 80% !important;
     height: 80% !important;
    }
}
</style>
<div class="container-flued">
<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
  <ol class="carousel-indicators">
    <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
  </ol>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img class="d-block w-100" src="images/s1.jpg" alt="First slide">
    </div>
    
    <div class="carousel-item">
      <img class="d-block w-100" src="images/s3.jpg" alt="Third slide">
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="images/s2.jpg" alt="Third slide">
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="images/s4.jpg" alt="Third slide">
    </div>
   <div class="carousel-item">
      <img class="d-block w-100" src="images/s5.jpg" alt="Second slide">
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="images/s6.jpg" alt="Second slide">
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="images/s7.jpg" alt="Third slide">
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="images/s8.jpg" alt="Third slide">
    </div>
      <div class="carousel-item">
      <img class="d-block w-100"  src="images/SLIDE 4-min.JPG" alt="Third slide">
    </div>

  </div>
  <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>

<section id="about">
 <div style="padding:50px 20px;" class="site-section">
<div class="container-flued">
  <h2  style="color:#0d325b" class="kitchen text-center wow slideInLeft">About Us</h2><br/>
  <div class="row">
  
    <div class="s2 col-md-6">
             
                <div class="text-justify col-md-12">
              <img style="background-size: cover;height:350px;width: 630px" class="c3" src="images/about.jpg"/>
                </div>
    </div>


    <div class="s2 col-md-6">
                <div class="text-justify col-md-12">
                  <h2  style="color:#000" class="sheading">Overview</h2><br/>
                <p style="color:black;font-size:12pt;" class="visionhead1">Access Private Limited (ASC) offers the convenience of online accesses to all citizens effectively ending the digital divide. You can now use our innovative process and extensive infrastructure and obtain these services close to home.
Access Private Limited offer assisted access of e-services to citizens with a focus on enhancing governance, special in Pan card services, Demat account opening, Ration Card Print delivering essential government and public utility services, social welfare schemes, financial services, education and skill development courses, health and agriculture services and digital literacy, apart from a host of B2C services, thereby making the e-services, particularly G2C services, Multiple service delivery points run by citizens competing with each other redefine governance and bring in strict adherence to citizen charter time limits.
</p>
                    
                   <a class="button" href="https://acses.in/aboutreadmore.php" role="button">Read More</a>
                </div>
    </div>
  </div>
</div>
</div>
</section>

<div style="padding:50px 20px;" class="site-section">
<div class="container">
  <h2  style="color:#0d325b" class="kitchen text-center wow slideInLeft">Our Services</h2><br/>
  <div class="row">
    <div class="s2 col-md-4">
        <div class="card" style="width: 18rem;padding-top: 20px;padding-bottom: 20px;padding-right: 20px;padding-left: 20px;">
              <h4 class="kitchen text-center">Government Service</h4>
                  <ul  style="line-height:200%;color: #666666;padding-bottom: 30px">
                    
                    <li><i class="fa fa-dot-circle-o"></i> Adharcard </li>
                    <li><i class="fa fa-dot-circle-o"></i> Pancard</li>
                    <li><i class="fa fa-dot-circle-o"></i> Passport </li>
                    <li><i class="fa fa-dot-circle-o"></i> Election</li>
                    
                  </ul>
                  <a class="button" href="http://localhost/ASC/government%20service.php" role="button">Read More</a>
      </div>  
    </div>


    <div class="s2 col-md-4">
         <div class="card" style="width: 18rem;padding-top: 20px;padding-bottom: 20px;padding-right: 20px;padding-left: 20px;">
              <h4 class="kitchen text-center">Insurance</h4>
                  <ul  style="line-height:200%;color: #666666;padding-bottom: 90px;">
                    
                    <li><i class="fa fa-dot-circle-o"></i>  General Insurance </li>
                   <!-- <li><i class="fa fa-dot-circle-o"></i> Farmer Package Policy</li>
                    <li><i class="fa fa-dot-circle-o"></i> Life Insurance </li>-->
                    <li><i class="fa fa-dot-circle-o"></i> Personal Accidental</li>
                    
                  </ul>
                  <a class="button" href="http://localhost/ASC/insurance.php" role="button">Read More</a>
      </div>  
    </div>

    <div class="s2 col-md-4">
        <div class="card" style="width: 18rem;padding-top: 20px;padding-bottom: 20px;padding-right: 20px;padding-left: 20px;">
              <h4 class="kitchen text-center">Digital Banks</h4>
                  <ul  style="line-height:200%;color: #666666;padding-bottom: 60px;">
                    
                    <li><i class="fa fa-dot-circle-o"></i>  DMT </li>
                    <li><i class="fa fa-dot-circle-o"></i> AEPS</li>
                    <li><i class="fa fa-dot-circle-o"></i> Micro ATM </li>
                  </ul>
                  <a class="button" href="https://acses.in/Digital%20Banks.php" role="button">Read More</a>
      </div>  
    </div>

  </div>
  <br>
  <div class="row">
    <div class="s2 col-md-4">
        <div class="card" style="width: 18rem;padding-top: 20px;padding-bottom: 20px;padding-right: 20px;padding-left: 20px;">
              <h4 class="kitchen text-center">Travel</h4>
                  <ul  style="line-height:200%;color: #666666;padding-bottom: 30px;">
                    
                    <li><i class="fa fa-dot-circle-o"></i>  Bus Tickets </li>
                    <li><i class="fa fa-dot-circle-o"></i> Flight Tickets</li>
                    <li><i class="fa fa-dot-circle-o"></i> Darshan Booking </li>
                  </ul>
                  <a class="button"  href="https://acses.in/travels.php" role="button">Read More</a>
      </div>  
    </div>


    <!--<div class="s2 col-md-4">
         <div class="card" style="width: 18rem;padding-top: 20px;padding-bottom: 20px;padding-right: 20px;padding-left: 20px;">
              <h4 class="kitchen text-center">Education</h4>
                  <ul  style="line-height:200%;color: #666666;">
                    
                    <li><i class="fa fa-dot-circle-o"></i>  SCLM Registration </li>
                    <li><i class="fa fa-dot-circle-o"></i> SCLM Admission</li>
                    <li><i class="fa fa-dot-circle-o"></i> Tally Certification </li>
                    <li><i class="fa fa-dot-circle-o"></i> eLegal Consultancy </li>
                  </ul>
                  <a class="button" href="http://localhost/ASC/education.php" role="button">Read More</a>
      </div>  
    </div>-->
<div class="s2 col-md-4">
        <div class="card" style="width: 18rem;padding-top: 20px;padding-bottom: 20px;padding-right: 20px;padding-left: 20px;">
              <h4 class="kitchen text-center">Loan</h4>
                  <ul  style="line-height:200%;color: #666666;padding-bottom: 35px;">
                    
                    <li><i class="fa fa-dot-circle-o"></i>  Secured </li>
                    <li><i class="fa fa-dot-circle-o"></i> Unsecured</li>
                    <li><i class="fa fa-dot-circle-o"></i> Auto Loan </li>
                  </ul>
                  <a class="button" href="https://acses.in/loan.php" role="button">Read More</a>
      </div> 
</div>
    <div class="s2 col-md-4">
        <div class="card" style="width: 18rem;padding-top: 20px;padding-bottom: 20px;padding-right: 20px;padding-left: 20px;">
              <h4 class="kitchen text-center">Others</h4>
                  <ul  style="line-height:200%;color: #666666;padding-bottom: 70px;">
                    
                    <li><i class="fa fa-dot-circle-o"></i>  PVC Card and Biometric Device </li>
                   <!-- <li><i class="fa fa-dot-circle-o"></i> Pradhan Mantri Awas Yojana</li>
                    <li><i class="fa fa-dot-circle-o"></i> Jeeevan Pramaan </li>
                    <li><i class="fa fa-dot-circle-o"></i> NIELIT Facilitation Centre </li>-->
                  </ul>
                  <a class="button"  href="https://acses.in/Others.php" role="button">Read More</a>
         </div> 
    </div>
  

</div>
<br>
 <!--div class="s2 col-md-4">
        <div class="card" style="width: 18rem;padding-top: 20px;padding-bottom: 20px;padding-right: 20px;padding-left: 20px;">
              <h4 class="kitchen text-center">Health</h4>
                  <ul  style="line-height:200%;color: #666666;">
                    
                    <li><i class="fa fa-dot-circle-o"></i>  Super Speciality Consultation </li>
                    <li><i class="fa fa-dot-circle-o"></i> Telemedicine</li>
                    <li><i class="fa fa-dot-circle-o"></i> Jan Aushadhi Registration </li>
                    <li><i class="fa fa-dot-circle-o"></i> Jiva Telemedine </li>
                  </ul>
                  <a class="button" href="http://localhost/ASC/health.php" role="button">Read More</a>
    </div>
  </div>
</div>-->


  
 <!-- <div class="row">
    <div class="s2 col-md-4">
        <div class="card" style="width: 18rem;padding-top: 20px;padding-bottom: 20px;padding-right: 20px;padding-left: 20px;">
              <h4 class="kitchen text-center">Others</h4>
                  <ul  style="line-height:200%;color: #666666;padding-bottom: 70px;">
                    
                    <li><i class="fa fa-dot-circle-o"></i>  PVC Card and Biometric Device </li>
                    <li><i class="fa fa-dot-circle-o"></i> Pradhan Mantri Awas Yojana</li>
                    <li><i class="fa fa-dot-circle-o"></i> Jeeevan Pramaan </li>
                    <li><i class="fa fa-dot-circle-o"></i> NIELIT Facilitation Centre </li>
                  </ul>
                  <a class="button"  href="http://localhost/ASC/Others.php" role="button">Read More</a>
         </div> 
    </div>
  </div>-->
</div>
</div>

<div style="padding:20px 20px;background-color:#296265 ;" class="site-section page-section small-section bg-coral">
<div class="container">
  <div class="row">
  
    <div class="s2 col-md-8">
             
                <div class="text-justify col-md-12">
              <h3 class="becomeasc"style="color:#fff;padding:20px">Become A ASC Distributor/ ASC Agent Join Now </h3>
                </div>
    </div>

    <div class="s2 col-md-4">
                <div class="text-justify col-md-12">
                <button type="button" class="button button1 " target="_blank">Contact Us</button>
                </div>
    </div>
  </div>
</div>
</div>
<!--
<section id="up">
<div style="padding:50px 20px;" class="site-section">
   <h2  style="color:#0d325b" class="kitchen text-center wow slideInLeft">Upcoming Services</h2><br/>
<div class="container" style="background:lavender;padding:40px" >
  
  <div class="row">
  
    <div class="s2 col-md-3">
         <img src="images/images.png" class="card-img-top" alt="">
         <h4  style="color:#000" class="kitchen text-center wow slideInLeft">Eseva</h4> 
               
    </div>


    <div class="s2 col-md-3">
             <img src="images/Digital-India-1.png" class="card-img-top" alt="">
             <h4  style="color:#000" class="kitchen text-center wow slideInLeft">Digital India</h4>
  </div>
  <div class="s2 col-md-3">
                <img src="images/images2.jpg" class="card-img-top" alt="">
                <h4  style="color:#000" class="kitchen text-center wow slideInLeft">Skill India</h4>
  </div>
  <div class="s2 col-md-3">
              <img src="images/images3.jpg" class="card-img-top" alt="">
              <h4  style="color:#000" class="kitchen text-center wow slideInLeft">Mee Seva</h4>  
  </div>
</div>

<div class="row">
  
    <div class="s2 col-md-3">
         <img src="images/images4.jpg" class="card-img-top" alt="">
         <h4  style="color:#000" class="kitchen text-center wow slideInLeft">Atal Seva</h4>   
               
    </div>


    <div class="s2 col-md-3">
             <img src="images/kk.png" class="card-img-top" alt="">
             <h4  style="color:#000" class="kitchen text-center wow slideInLeft">Eseva</h4>
  </div>
  <div class="s2 col-md-3">
                <img src="images/unnamed.jpg" class="card-img-top" alt="">
                <h4  style="color:#000" class="kitchen text-center wow slideInLeft">ESeva</h4>
  </div>
  <div class="s2 col-md-3">
              <img src="images/images4.jpg" class="card-img-top" alt="">
              <h4  style="color:#000" class="kitchen text-center wow slideInLeft">ESeva</h4>  
  </div>
</div>
<div class="row">
  
    <div class="s2 col-md-3">
         <img src="images/images3.jpg" class="card-img-top" alt="">
         <h4  style="color:#000" class="kitchen text-center wow slideInLeft">ESeva</h4>    
               
    </div>


    <div class="s2 col-md-3">
             <img src="images/images4.jpg" class="card-img-top" alt="">
             <h4  style="color:#000" class="kitchen text-center wow slideInLeft">ESeva</h4>
  </div>
  <div class="s2 col-md-3">
                <img src="images/images3.jpg" class="card-img-top" alt="">
                <h4  style="color:#000" class="kitchen text-center wow slideInLeft">ESeva</h4>
  </div>
  <div class="s2 col-md-3">
              <img src="images/unnamed.jpg" class="card-img-top" alt="">
              <h4  style="color:#000" class="kitchen text-center wow slideInLeft">ESeva</h4>  
  </div>
</div>
</div>
</div>
</section>-->
<div style="padding:20px 20px;background-color:  #e5e5e5 " class="site-section" >
<div class="container-flued">
  <h3 style="color:#0d325b ;font-size: 32px;margin-top:20px" class="kitchen text-center wow slideInLeft">Vision </h2>
 <br/>
  <div class="row">
     
    
    <div class="text-justify col-md-6"style="background-color:  #e5e5e5">
      
              <img style="background-size: cover;height:150px;margin-top: 10px;" class="shadow-lg d-block w-30 rounded mx-auto d-block" src="images/v1.png"/>
    </div>
    <div class="text-justify col-md-6" style="background-color:  #e5e5e5" >
              
             
              
               <p style="color:black;font-size:12pt;padding-right: 40px; margin-top: 20px;" class="wow slideInLeft">• In the vision of Access Private Limited, We are connecting people empowering them as to serve people by their own hands with the help of technology, IT-enabled network of citizen service points connecting local population with government departments, business establishments, banks, insurance companies and educational institutions.</p>
                   
    </div>
    
</div>
  <h3 style="color:#0d325b ;font-size: 32px;margin-top:20px" class="kitchen text-center wow slideInLeft">Mission </h2>
<br/>
 <div class="row">
    <div class="text-justify col-md-6" style="background-color:  #e5e5e5" >
      
             
              
               <p style="color:black;font-size:12pt;padding-left: 40px" class="wow slideInLeft">• Concurring to the mission of Access Private Limited- IT-enabled network of citizen service points connecting the local population with Business Establishments.</p>
                    <p  style="color:black;font-size:12pt;padding-left: 40px" class="wow slideInLeft">• ASC is enabling the rural ecommerce model through its Access Private Limited network, where the Access Private Limited reaches to its customers’ doorstep.
                </p>
                <p  style="color:black;font-size:12pt;padding-left: 40px" class="wow slideInLeft">• ASC is enabling the rural ecommerce model through its Access Private Limited network, where the Access Private Limited reaches to its customers’ doorstep.
                </p>
                </p>

                
    </div>
    <div class="text-justify col-md-6"style="background-color: #e5e5e5">
              <img style="background-size: cover;height:180px;" class="shadow-lg d-block w-30 rounded mx-auto d-block" src="images/m1.png"/>
    </div>
</div>
    
      
  </div>
</div>
</div>




<!--
<div style="padding:20px 20px;" class="site-section">
<div class="container-flued">
  <h2  style="color:#0d325b" class="kitchen text-center wow slideInLeft">Vision Mission</h2><br/>
  <div class="row">
    <div class="text-justify col-md-6">
              <img style="background-size: cover;height:150px;" class="shadow-lg d-block w-30 rounded mx-auto d-block" src="images/v1.png"/>
              <h3  style="color:#000" class="kitchen text-center wow slideInLeft">Vision</h3><br/>
               <p style="color:black;font-size:12pt;padding-right:20px;padding-left: 30px" class="visionhead">In the vision of Access Private Limited, We are connecting people empowering them as to serve people by their own hands with the help of technology, IT-enabled network of citizen service points connecting local population with government departments, business establishments, banks, insurance companies and educational institutions.</p>
                   
    </div>

    <div class="text-justify col-md-6">
              <img style="background-size: cover;height:150px" class="shadow-lg d-block w-30 rounded mx-auto d-block" src="images/m1.png"/>
              <h3  style="color:#000" class="kitchen text-center wow slideInLeft">Mission</h3><br/>
               <p style="color:black;font-size:12pt;padding-right: 30px;padding-left: 30px" class="visionhead">• Concurring to the mission of Access Private Limited- IT-enabled network of citizen service points connecting the local population with Business Establishments.</p>
                    <p  style="color:black;font-size:12pt;padding-right:30px;padding-left: 30px" class="visionhead">• ASC is enabling the rural ecommerce model through its Access Private Limited network, where the Access Private Limited reaches to its customers’ doorstep.
                </p>

                  <p  style="color:black;font-size:12pt;padding-right: 30px;padding-left: 30px" class="visionhead">• ASC is enabling the rural ecommerce model through its Access Private Limited network, where the Access Private Limited reaches to its customers’ doorstep.
                </p>
                
                
    </div>
  </div>
</div>
</div>


-->

<div style="padding:20px 20px;" class="site-section">
<div class="container-flued">
  <h2  style="color:#0d325b" class="kitchen text-center wow slideInLeft">Why To Choose Us</h2><br/>
  <div class="row">
    <div class="text-justify col-md-6">
             
              
          
               <p style="color:black;font-size:12pt;padding-right: 30px;padding-left: 40px" class="wow slideInLeft"> • The reason we are able to deliver amazing results is our in-depth understanding of latest technological trends, tools and the ‘in’ thing in the digital world. Our team members collaborate and innovate to find creative solutions as per your needs, requirements and expectations.
</p>
                    <p  style="color:black;font-size:12pt;padding-right: 30px;padding-left: 40px" class="wow slideInLeft">• We don’t believe in delivering only the agreed amount of work but a lot more than we agree to. This is mainly because we find ourselves ‘CRAZY’, ‘PASSIONATE’ and sternly ‘COMMITED’ towards our work.
                </p>
                  <p  style="color:black;font-size:12pt;padding-right: 30px;padding-left: 40px" class="wow slideInLeft">• We don’t believe in leaving a task unaccomplished or in not delivering the committed results. Our team consists of individuals who are completely dedicated to their work and will do everything under the sun to meet the deadlines.
                </p>
                
                  <p  style="color:black;font-size:12pt;padding-right: 30px;padding-left: 40px" class="wow slideInLeft">• 
We don’t believe in making it expensive for you, but we believe in making it extremely good by providing unique and cost-effective digital solutions. We create genuine customer value with our one-stop website development, content and digital marketing solutions.

                </p>
                
                  <p  style="color:black;font-size:12pt;padding-right: 30px;padding-left:40px" class="wow slideInLeft">• We like being easily approachable; warm and receptive to the ideas of our clients. One thing we hate doing is making our clients wait for anything- calls, messages or even COFFEE!•
                </p>
                
                
                   
    </div>

    <div class="text-justify col-md-6">
              <img style="background-size: cover;height:450px;width:600px" class="shadow-lg d-block w-30 rounded mx-auto d-block" src="images/Advantages.jpg"/>

                
                
    </div>
  </div>
</div>
</div>


<!--
<section id="wcu">
 <div style="padding:50px 20px;background-color: #e5e5e5;" class="site-section">
<div class="container-flued">
  <h2  style="color:#0d325b" class="kitchen text-center wow slideInLeft">Why Choose Us</h2><br/>
  <div class="row">


    <div class="s2 col-md-12">
                <div class="text-justify col-md-12">
                <p style="color:black;font-size:12pt;padding-right: 30px;padding-left: 30px" class="wow slideInLeft"> • The reason we are able to deliver amazing results is our in-depth understanding of latest technological trends, tools and the ‘in’ thing in the digital world. Our team members collaborate and innovate to find creative solutions as per your needs, requirements and expectations.
</p>
                    <p  style="color:black;font-size:12pt;padding-right: 30px;padding-left: 30px" class="wow slideInLeft">• We don’t believe in delivering only the agreed amount of work but a lot more than we agree to. This is mainly because we find ourselves ‘CRAZY’, ‘PASSIONATE’ and sternly ‘COMMITED’ towards our work.
                </p>
                  <p  style="color:black;font-size:12pt;padding-right: 30px;padding-left: 30px" class="wow slideInLeft">• We don’t believe in leaving a task unaccomplished or in not delivering the committed results. Our team consists of individuals who are completely dedicated to their work and will do everything under the sun to meet the deadlines.
                </p>
                
                  <p  style="color:black;font-size:12pt;padding-right: 30px;padding-left: 30px" class="wow slideInLeft">• 
We don’t believe in making it expensive for you, but we believe in making it extremely good by providing unique and cost-effective digital solutions. We create genuine customer value with our one-stop website development, content and digital marketing solutions.

                </p>
                
                  <p  style="color:black;font-size:12pt;padding-right: 30px;padding-left:30px" class="wow slideInLeft">• We like being easily approachable; warm and receptive to the ideas of our clients. One thing we hate doing is making our clients wait for anything- calls, messages or even COFFEE!•
                </p>
                
                
                </div>
    </div>
  </div>
</div>
</div>
</section>-->
<!--
<div style="padding:100px 20px;" class="site-section">
<div class="container-flued">
  <div class="row">
    <div class="s2 col-md-6">
                <div class="text-justify col-md-12">
                  <h2  style="color:#0d325b" class="kitchen text-left wow slideInLeft">Advantages Of ASC</h2><br/>
                <p style="color:black;font-size:12pt;" class="wow slideInLeft">A simply a term used for the modern-day kitchen 
                    furniture layout which is especially designed to optimize functionality and the use of space.
                     These kitchens use various modules (units) of cabinets that are crafted out of diverse materials
                    and hold kitchen accessories inside.</p>
                    <p  style="color:black;font-size:12pt;" class="wow slideInLeft">The basic structure of a modular kitchen is extremely practical. The units on the floor are called 'base cabinets' and serve as the foundation for the kitchen worktop which is usually made out of granite, marble, tile or wood. The ones fastened on the wall for storage purposes are known as 'wall cabinets'.
                </p>
               <a class="button" href="#" role="button">Read More</a>
                </div>
    </div>

    <div class="text-justify col-md-6">
              <img style="background-size: cover;height:350px" class="shadow-lg d-block w-100" src="images/Slide-1.jpg"/>
    </div>
  </div>
</div>
</div>-->

<section id="partners" style="padding:30px 30px;">
<div class="container">
   <h2  style="color:#000" class="kitchen text-center wow slideInLeft">Our Partners</h2><br/>
   <div class="customer-logos">
  
  
  <div class="slide"><img src="images/HDFC_Bank_logo.png"></div>
  <div class="slide"><img src="images/ICICIBank.png"></div>
  <div class="slide"><img src="images/sbi.png"></div>
  <div class="slide"><img src="images/axis.png"></div>
  <div class="slide"><img src="images/idfcnew.png"></div>
  <div class="slide"><img src="images/yes.png"></div>
  <div class="slide"><img src="images/bbj.jpeg"></div>
  
</div>
</div>
</section>
</div>
<?php include"footer.php"?>

<script>
$(document).ready(function(){
      $('.customer-logos').slick({
        slidesToShow: 4,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 1000,
        arrows: false,
        dots: false,
          pauseOnHover: false,
          responsive: [{
          breakpoint: 768,
          settings: {
            slidesToShow: 3
          }
        }, {
          breakpoint: 520,
          settings: {
            slidesToShow: 2
          }
        }]
      });
    });
</script>

