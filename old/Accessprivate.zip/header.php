<?php include"link.php"?>
<style>

</style>
<nav class="navbar navbar-expand-lg  navbar-dark bg-white" >
  <a class="navbar-brand" href="#"> <img style="background-size: cover;height:80px;width:350px" class="logof" src="images/finalAI.png"/></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav ml-auto">
      <li class="nav-item active">
        <a class="nav-link" href="https://localhost/Accessprivate/index.php" style="color:black">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#about" style="color:black">About Us</a>
      </li>
  
    
    <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="color:black">
          Our Services
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="https://localhost/Accessprivate/government service.php" >Government Service</a>
          <a class="dropdown-item" href="https://localhost/Accessprivate/insurance.php">Insurance</a>
          <a class="dropdown-item" href="https://localhost/Accessprivate/Digital Banks.php">Digital Banks</a>
          <a class="dropdown-item" href="https://localhost/Accessprivate/travels.php">Travel</a>
       <!--   <a class="dropdown-item" href="http://localhost/ASC/education.php">Education</a>-->
        <!--  <a class="dropdown-item" href="http://localhost/ASC/health.php">Health</a>-->
          <a class="dropdown-item" href="https://localhost/Accessprivate/loan.php">Loan</a>
          <a class="dropdown-item" href="https://localhost/Accessprivate/Others.php">Others</a>
        </div>
      </li>
      </li>


   <!-- <li class="nav-item">
        <a class="nav-link" href="#up">Upcoming Services</a>
      </li>-->
    <li class="nav-item">
        <a class="nav-link" href="#wcu" style="color:black">Why Choose Us</a>
      </li>
    <li class="nav-item">
        <a class="nav-link" href="#partners" style="color:black">Our Partners</a>
      </li>
       <li class="nav-item">
        <button type="button" class="btn btn-success" style="margin-top:11px;background-color: #74b1a8 !important">Join Now</button>
      </li>
      
    </ul>
   
  </div>
</nav>