 <?php include "link.php"?>
 <?php include "header.php"?>


 <div id="element-with-background-image">
   <div id="color-overlay"></div>
  <img  class="w3-round"  style="width:100%;background-color:purple;height:20%">
   <div class="centered">Others</div>
</div>


<div style="padding:50px 20px;" class="site-section">
<div class="container">
 <div class="row">
  <div class="s2 col-md-6">
             <div class="text-justify col-md-12">
                <img style="background-size: cover;height:350px;width:500px" class="o1" src="images/pvccard.jpg"/>
            </div>
    </div>


    <div class="s2 col-md-6">
        <div class="text-justify col-md-12">
                  <h2  style="color:#000" class="sheading">PVC Card and Biometric Device</h2><br/>
                <p style="color:black;font-size:12pt;" class="wow slideInLeft">Access Private Limited (ASC) offers the convenience of online accesses to all citizens effectively ending the digital divide. You can now use our innovative process and extensive infrastructure and obtain these services close to home.
Access Private Limited offer assisted access of e-services to citizens with a focus on enhancing governance, special in Pan card services, Demat account opening, Ration Card Print delivering essential government and public utility services, social welfare schemes, financial services, education and skill development courses, health and agriculture services and digital literacy, apart from a host of B2C services, thereby making the e-services, particularly G2C services, Multiple service delivery points run by citizens competing with each other redefine governance and bring in strict adherence to citizen charter time limits.
</p>
                     <a class="button" href="#" role="button">Contact Us</a>
        </div>
    </div>
  </div>
</div>
</div>

<!--<div style="padding:50px 20px;" class="site-section">
<div class="container">
 <div class="row">
  <div class="s2 col-md-6">
    <div class="text-justify col-md-12">
                             <h2  style="color:#000" class="kitchen text-left wow slideInLeft">Pradhan Mantri Awas Yojana</h2><br/>
                            <p style="color:black;font-size:12pt;" class="wow slideInLeft">Access Private Limited (ASC) offers the convenience of online accesses to all citizens effectively ending the digital divide. You can now use our innovative process and extensive infrastructure and obtain these services close to home.
Access Private Limited offer assisted access of e-services to citizens with a focus on enhancing governance, special in Pan card services, Demat account opening, Ration Card Print delivering essential government and public utility services, social welfare schemes, financial services, education and skill development courses, health and agriculture services and digital literacy, apart from a host of B2C services, thereby making the e-services, particularly G2C services, Multiple service delivery points run by citizens competing with each other redefine governance and bring in strict adherence to citizen charter time limits.
</p>
  <a class="button" href="#" role="button">Contact Us</a>
    </div>
        </div>

    <div class="s2 col-md-6">
                <div class="text-justify col-md-12">
                    <img style="background-size: cover;height:350px" class="shadow-lg d-block w-100" src="images/eseva.jpg"/>
                </div>
    </div>
  </div>
</div>
</div>

<div style="padding:50px 20px;" class="site-section">
<div class="container">
 <div class="row">
  <div class="s2 col-md-6">
             <div class="text-justify col-md-12">
                <img style="background-size: cover;height:350px" class="shadow-lg d-block w-100" src="images/eseva.jpg"/>
            </div>
    </div>


    <div class="s2 col-md-6">
        <div class="text-justify col-md-12">
                  <h2  style="color:#000" class="kitchen text-left wow slideInLeft">Jeeevan Pramaan</h2><br/>
                <p style="color:black;font-size:12pt;" class="wow slideInLeft">Access Private Limited (ASC) offers the convenience of online accesses to all citizens effectively ending the digital divide. You can now use our innovative process and extensive infrastructure and obtain these services close to home.
Access Private Limited offer assisted access of e-services to citizens with a focus on enhancing governance, special in Pan card services, Demat account opening, Ration Card Print delivering essential government and public utility services, social welfare schemes, financial services, education and skill development courses, health and agriculture services and digital literacy, apart from a host of B2C services, thereby making the e-services, particularly G2C services, Multiple service delivery points run by citizens competing with each other redefine governance and bring in strict adherence to citizen charter time limits.
</p>
                    <a class="button" href="#" role="button">Contact Us</a>
        </div>
    </div>
  </div>
</div>
</div>

<div style="padding:50px 20px;" class="site-section">
<div class="container">
 <div class="row">
  <div class="s2 col-md-6">
    <div class="text-justify col-md-12">
                             <h2  style="color:#000" class="kitchen text-left wow slideInLeft">NIELIT Facilitation Centre</h2><br/>
                            <p style="color:black;font-size:12pt;" class="wow slideInLeft">Access Private Limited (ASC) offers the convenience of online accesses to all citizens effectively ending the digital divide. You can now use our innovative process and extensive infrastructure and obtain these services close to home.
Access Private Limited offer assisted access of e-services to citizens with a focus on enhancing governance, special in Pan card services, Demat account opening, Ration Card Print delivering essential government and public utility services, social welfare schemes, financial services, education and skill development courses, health and agriculture services and digital literacy, apart from a host of B2C services, thereby making the e-services, particularly G2C services, Multiple service delivery points run by citizens competing with each other redefine governance and bring in strict adherence to citizen charter time limits.
</p>
  <a class="button" href="#" role="button">Contact Us</a>
    </div>
</div>

    <div class="s2 col-md-6">
                <div class="text-justify col-md-12">
                    <img style="background-size: cover;height:350px" class="shadow-lg d-block w-100" src="images/eseva.jpg"/>
                </div>
    </div>
  </div>
</div>-->
</div>

<style>
.centered {
  color: #fff;
  font-size: 40px;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
}
#element-with-background-image 
{
   position: relative;  
}
 
#color-overlay 
{
   position: absolute;
   top: 0;
   left: 0;
   width: 100%;
   height: 100%;
   background-color: #000;
   opacity: 0.6;
}
</style>
<?php include"footer.php"?>