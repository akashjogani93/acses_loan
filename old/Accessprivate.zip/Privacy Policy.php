 <?php include "link.php"?>
 <?php include "header.php"?>


<div id="element-with-background-image">
   <div id="color-overlay"></div>
   <img src="images/app.jpeg" class="w3-round" alt="Snow" style="width:100%;">
   <div class="centered">ASC Privacy Policy</div>
</div>

 


<div style="padding:50px 20px;" class="site-section">
<div class="container">
 <div class="row">
    <div class="s2 col-md-12">
        <div class="text-justify col-md-12">
                  <h2  style="color:#000" class="kitchen text-center wow slideInLeft">ASC Privacy Policy</h2><br/>
             </div>   
</p>
<p style="color:black;font-size:13pt;" class="wow slideInLeft">your privacy is very important to us, which is why we've created a separate privacy policy in order to explain in detail How we collect, manage, process, secure, and store your private information. Our privacy policy is included under the Scope of this user agreement.
</p>
<br>

        </div>
    </div>
  </div>
</div>
</div>

<style>
.centered {
  color: #fff;
  font-size: 40px;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
}

#element-with-background-image 
{
   position: relative;  
}
 
#color-overlay 
{
   position: absolute;
   top: 0;
   left: 0;
   width: 100%;
   height: 100%;
   background-color: #000;
   opacity: 0.6;
}
</style>
<?php include"footer.php"?>