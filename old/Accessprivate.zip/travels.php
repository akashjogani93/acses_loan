 <?php include "link.php"?>
 <?php include "header.php"?>


 <div id="element-with-background-image">
   <div id="color-overlay"></div>
  <img  class="w3-round"  style="width:100%;background-color:purple;height:20%">
   <div class="centered">Travel</div>
</div>


<div style="padding:50px 20px;" class="site-section">
<div class="container">
 <div class="row">
  <div class="s2 col-md-6">
             <div class="text-justify col-md-12">
                <img style="background-size: cover;height:350px;width:500px" class="t1" src="images/bustiket.jpg"/>
            </div>
    </div>


    <div class="s2 col-md-6">
        <div class="text-justify col-md-12">
                  <h2  style="color:#000" class="sheading">Bus Tickets</h2><br/>
                <p style="color:black;font-size:12pt;" class="wow slideInLeft">Online Bus Ticket Reservation System is a Web based application that works within a centralized network. This project presents a review on the software program "Online Bus Ticket Reservation System" as should be used in a bus transportation system, a facility which is used to reserve seats, cancellation of reservation and different types of route enquiries used on securing quick reservations. OBTRS is built for managing and computerizing the traditional database, ticket booking and tracking bus and travel made. It maintains all customer details, bus details, reservation details.
</p>
                     <a class="button" href="#" role="button">Contact Us</a>
        </div>
    </div>
  </div>
</div>
</div>

<div style="padding:50px 20px;" class="site-section">
<div class="container">
 <div class="row">
  <div class="s2 col-md-6">
    <div class="text-justify col-md-12">
                             <h2  style="color:#000" class="sheading"> Flight Tickets</h2><br/>
                            <p style="color:black;font-size:12pt;" class="wow slideInLeft">When a person books a flight, less than 15 minutes pass between their starting to fill in the search form and a booking confirmation appearing in their mailbox. From the airline side, it involves many events and systems to issue a ticket and make sure that the right person will board the plane. In this article, we describe the flight booking pipeline and explain the main processes supporting it.
</p>
  <a class="button" href="#" role="button">Contact Us</a>
    </div>
        </div>

    <div class="s2 col-md-6">
                <div class="text-justify col-md-12">
                    <img style="background-size: cover;height:350px;width:500px" class="t2" src="images/flightticket.jpg"/>
                </div>
    </div>
  </div>
</div>
</div>

<div style="padding:50px 20px;" class="site-section">
<div class="container">
 <div class="row">
  <div class="s2 col-md-6">
             <div class="text-justify col-md-12">
                <img style="background-size: cover;height:350px;width:500px" class="t3" src="images/SLIDE 10-min.JPG"/>
            </div>
    </div>


    <div class="s2 col-md-6">
        <div class="text-justify col-md-12">
                  <h2  style="color:#000" class="sheading">Darshan Booking</h2><br/>
                <p style="color:black;font-size:12pt;" class="wow slideInLeft">
We are the people, the heart and the soul of the Darshan's of every historical places , the leading of ur destiny is Our job, every day, is to exceed your expectations and make sure we transform your stay with us in an unforgettable experience.
</p>
                    <a class="button" href="#" role="button" style="margin-top:80px">Contact Us</a>
        </div>
    </div>
  </div>
</div>
</div>
<style>
.centered {
  color: #fff;
  font-size: 40px;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
}
#element-with-background-image 
{
   position: relative;  
}
 
#color-overlay 
{
   position: absolute;
   top: 0;
   left: 0;
   width: 100%;
   height: 100%;
   background-color: #000;
   opacity: 0.6;
}
</style>
<?php include"footer.php"?>